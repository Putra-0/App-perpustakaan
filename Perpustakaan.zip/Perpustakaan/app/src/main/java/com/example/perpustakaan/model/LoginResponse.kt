package com.example.perpustakaan.model

data class LoginResponse(val status: Boolean, val message:String, val user: User)