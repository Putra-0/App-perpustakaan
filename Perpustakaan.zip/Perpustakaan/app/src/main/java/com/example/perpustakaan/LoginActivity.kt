package com.example.perpustakaan

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.perpustakaan.api.RetrofitClient
import com.example.perpustakaan.model.LoginResponse
import com.example.perpustakaan.storage.SharedPreference
import kotlinx.android.synthetic.main.activity_login.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class LoginActivity : AppCompatActivity() {
    private lateinit var sPH: SharedPreference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        sPH = SharedPreference(this)

        btnLogin.setOnClickListener {
            val email = etEmail.text.toString()
            val password = etPassword.text.toString()

            if(email.isEmpty() || password.isEmpty()) {
                etEmail.error = "Isi dulu bosku!"
                etPassword.error = "Isi dulu bosku !"
                return@setOnClickListener
            }

            val api = RetrofitClient.instanceRetrofit

            api.login(email, password).enqueue(object: Callback<LoginResponse> {
                override fun onResponse(
                    call: Call<LoginResponse>,
                    response: Response<LoginResponse>
                ) {
                    val respon = response.body()

                    if (respon != null) {
                        if (respon.status == false){
                            Toast.makeText(this@LoginActivity, respon.message, Toast.LENGTH_SHORT).show()
                        } else {
                            sPH.setStatusLogin(true)
                            val i = Intent(this@LoginActivity, MainActivity::class.java)
                            Toast.makeText(
                                this@LoginActivity,
                                respon.message,
                                Toast.LENGTH_SHORT
                            ).show()
                            startActivity(i)
                            finish()
                        }
                    }
                }

                override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                    Toast.makeText(this@LoginActivity, t.localizedMessage, Toast.LENGTH_SHORT).show()
                }
            } )


        }
    }
}