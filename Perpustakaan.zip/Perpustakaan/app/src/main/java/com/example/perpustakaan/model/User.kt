package com.example.perpustakaan.model

data class User(val id:Int, val email: String?, val name: String?)